# Deep-Learning-Lab-Assignments-SPPU
This repository contains a collection of deep learning assignments designed for the SPPU (Savitribai Phule Pune University) 2019 pattern curriculum. These assignments are intended to help students learn and practice fundamental concepts and techniques in deep learning.
